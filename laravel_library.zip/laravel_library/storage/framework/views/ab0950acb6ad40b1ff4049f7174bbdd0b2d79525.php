<?php $__env->startSection('title', 'Edit Global Setting'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Edit Global Setting
            <small>Edit Global Setting Details</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo e(url('/global-setting')); ?>"><i class="fa fa-file-text"></i> Global Setting</a></li>
            <li class="active">Edit Global Setting</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <?php echo $__env->make('layouts/message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title">Global Setting</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form  name="global_setting_form" id="global_setting_form" role="form" method="post"  enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <!-- text input -->
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" placeholder="Enter ..." name="sitename" id="sitename" value="<?php echo e(($global_setting_info->name) ? $global_setting_info->name : ''); ?>" disabled="">
                    </div>
                    <div class="form-group">
                        <label>Value</label>

                        <?php if($global_setting_info->field_type =='1'): ?>

                        <input type="text" class="form-control" placeholder="Enter ..." name="global_setting_value" id="global_setting_value" value="<?php echo e(($global_setting_info->value) ? $global_setting_info->value : ''); ?>">
                        <?php elseif($global_setting_info->field_type =='2'): ?>
                        <textarea class="form-control" placeholder="Enter ..." name="global_setting_value" id="global_setting_value"><?php echo e(($global_setting_info->value) ? $global_setting_info->value : ''); ?></textarea>
                        <?php elseif($global_setting_info->field_type =='3'): ?>
                        <label>Select image to upload:</label>
                        <input type="file" name="logo" id="file">

                        <br/>
                        <?php if($global_setting_info->value): ?>
                        <img  src="<?php echo e(asset('/uploads/'.$global_setting_info->value)); ?>" title="logo" height="150" width="150" />
                        <?php endif; ?>

                        <?php else: ?>
                        <?php endif; ?>

                        <?php if($errors->has('global_setting_value')): ?>
                        <div class="text-danger"><?php echo e($errors->first('global_setting_value')); ?></div>
                        <?php endif; ?> </div>

                    <div class="box-footer">
                        <input type="hidden" name="global_setting_id" id="global_setting_id" value="<?php echo e(base64_encode($global_setting_info->id)); ?>" />
                        <input type="hidden" name="setting_id" id="setting_id" value="<?php echo e($global_setting_info->id); ?>" />

                        <button type="submit" class="btn btn-primary" id="btn_submit">Submit</button>
                        <a class="btn btn-default" href="<?php echo e(url('/global-setting')); ?>">Cancel</a>
                    </div>

                </form>
            </div>
            <!-- /.box-body -->
        </div>
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_content'); ?>
<script src="<?php echo e(asset('/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/admin/edit_global_setting.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>