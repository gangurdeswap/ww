<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title><?php echo e(GlobalSetting::getGlobal('sitename')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
        <!-- Bootstrap -->
        <link href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrapcdn.font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/css/animate.css')); ?>">
        <link href="<?php echo e(asset('/css/animate.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet" />
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
        <?php echo $__env->yieldContent('css_content'); ?>
        <script>
            var javascript_path = '<?php echo e(url("/")); ?>';
        </script>
        <?php
        $all_segment = Request::segments();
        ?>
    </head>
    <body>
        <header id="header">
            <nav class="navbar navbar-default navbar-static-top" role="banner">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <div class="navbar-brand">
                            <a href="<?php echo e(url('/')); ?>"><img width="106px" height="46px" src="<?php echo e(asset('uploads/'.GlobalSetting::getGlobal('logo'))); ?>" /></a>
                        </div>
                    </div>
                    <div class="navbar-collapse collapse">
                        <div class="menu">
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation"><a href="<?php echo e(url('/')); ?>" <?php if(count($all_segment)==0): ?> class="active" <?php endif; ?>><?php echo app('translator')->getFromJson('welcome_page.home'); ?></a></li>
                                <li role="presentation"><a href="<?php echo e(url('/about-us')); ?>" <?php if(in_array('about-us',$all_segment)): ?> class="active" <?php endif; ?>><?php echo app('translator')->getFromJson('welcome_page.about_us'); ?></a></li>
                                <li role="presentation"><a href="<?php echo e(url('/term-and-condition')); ?>"  <?php if(in_array('term-and-condition',$all_segment)): ?> class="active" <?php endif; ?>><?php echo app('translator')->getFromJson('welcome_page.terms_and_condition'); ?></a></li>
                                <li role="presentation"><a href="<?php echo e(url('/privacy-policy')); ?>"  <?php if(in_array('privacy-policy',$all_segment)): ?> class="active" <?php endif; ?>><?php echo app('translator')->getFromJson('welcome_page.privacy_policy'); ?></a></li>
                                <li role="presentation"><a href="<?php echo e(url('/contact')); ?>"  <?php if(in_array('contact',$all_segment)): ?> class="active" <?php endif; ?>><?php echo app('translator')->getFromJson('welcome_page.contact'); ?></a></li>
                                <?php if(env('IS_MULTILANGUAGE')): ?>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e(\Session::has('userLangName')?\Session::get('userLangName'):'Language'); ?></a>
                                    <div class="dropdown-menu">
                                        <?php
                                        $all_languages = App\Language::all();
                                        ?>
                                        <?php $__currentLoopData = $all_languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="dropdown-item lang_change_top" href="javascript:void(0);" data-val="<?php echo e($language->lang_code); ?>">  <?php echo e($language->lang_title); ?></a><br/>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div><!--/.container-->
            </nav><!--/nav-->
        </header><!--/header-->
        <?php if(session('status')): ?>
        <div class=" status alert alert-success" title="<?php echo e(session('status')); ?>" tabindex="0">
            <a href="javascript:void(0)" class="close dirtyignoreAnchor" >&times;</a>
            <?php echo e(session('status')); ?>

            <?php session()->forget('status'); ?>
        </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
        <div class=" status alert alert-success" title="<?php echo e(session('success')); ?>" tabindex="0" >
            <a href="javascript:void(0)" class="close dirtyignoreAnchor">&times;</a>
            <?php echo e(session('success')); ?>

            <?php session()->forget('success'); ?>
        </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class=" status alert alert-danger" title="<?php echo e(session('error')); ?>" tabindex="0">
            <a href="javascript:void(0)" class="close dirtyignoreAnchor">&times;</a>
            <?php echo e(session('error')); ?>

            <?php session()->forget('error'); ?>
        </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
        <footer>
            <div class="container">
                <div class="col-md-12 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
                    <h4>About Us</h4>
                    <p>Day is tellus ac cursus commodo, mauesris condime ntum nibh, ut fermentum mas justo sitters.</p>
                    <div class="contact-info">
                        <ul>
                            <li><i class="fa fa-home fa"></i>Suite 54 Elizebth Street, Victoria State Newyork, USA </li>
                            <li><i class="fa fa-phone fa"></i> +38 000 129900</li>
                            <li><i class="fa fa-envelope fa"></i> info@domain.net</li>
                        </ul>
                    </div>
                </div>
        </footer>
        <div class="sub-footer">
            <div class="container">
                <div class="social-icon">
                    <div class="col-md-4">
                        <ul class="social-network">
                            <li><a href="#" class="fb tool-tip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#" class="twitter tool-tip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#" class="gplus tool-tip" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#" class="linkedin tool-tip" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#" class="ytube tool-tip" title="You Tube"><i class="fa fa-youtube-play"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-4 col-md-offset-4">
                    <div class="copyright">
                        &copy; Day 2015 by <a target="_blank" href="http://bootstraptaste.com/" title="Free Twitter Bootstrap WordPress Themes and HTML templates">Bootstrap Themes</a>.All Rights Reserved.
                    </div>
                    <!--
                    All links in the footer should remain intact.
                    Licenseing information is available at: http://bootstraptaste.com/license/
                    You can buy this theme without footer links online at: http://bootstraptaste.com/buy/?theme=Day
                    -->
                </div>
            </div>
        </div>

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="<?php echo e(asset('/js/jquery.min.js')); ?>"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/common.js')); ?>"></script>
        <?php echo $__env->yieldContent('js_content'); ?>
    </body>
</html>