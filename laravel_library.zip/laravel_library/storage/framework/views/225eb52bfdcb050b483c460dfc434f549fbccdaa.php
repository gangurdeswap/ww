<?php $__env->startSection('title', 'Welcome'); ?>
<?php $__env->startSection('content'); ?>

<div class="about">
    <div class="container">
        <div class="text-center">
            <h2><?php echo e(!empty($cms_details->cmsLang)? ucwords($cms_details->cmsLang->page_title):''); ?></h2>
            <div class="col-md-10 col-md-offset-1">
                <?php if(!empty($cms_details->cmsLang)): ?>
                <p><?php echo $cms_details->cmsLang->page_content; ?></p>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>
<hr>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_content'); ?>
<script src="<?php echo e(asset('/js/wow.min.js')); ?>"></script>
<script>
wow = new WOW(
        {

        })
        .init();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>