<?php $__env->startSection('title', 'Edit Cms'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Edit CMS
            <small>Edit cms pages</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo e(url('/cms')); ?>"><i class="fa fa-file-text"></i> Cms Pages</a></li>
            <li class="active">Edit CMS</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="box box-warning">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo e(ucfirst(implode(' ',explode('-',$cms_info->page_name)))); ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form role="form" method="post">
                    <?php echo e(csrf_field()); ?>

                    <!-- text input -->
                    <div class="form-group">
                        <label>Page Title</label>
                        <input type="text" class="form-control" placeholder="Enter ..." name="page_title" id="page_title" value="<?php echo e(isset($cms_info->cmsLang)?$cms_info->cmsLang->page_title:''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Page Content</label>
                        <textarea class="form-control" placeholder="Enter ..." name="page_content" id="page_content"><?php echo e(isset($cms_info->cmsLang)?$cms_info->cmsLang->page_content:''); ?></textarea>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>

                </form>
            </div>
            <!-- /.box-body -->
        </div>
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_content'); ?>
<script src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>"></script>
<script src        ="<?php echo e(asset('/js/admin/edit_cms.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>