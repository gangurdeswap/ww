<?php $__env->startSection('title', 'Reply'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Reply
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo e(url('/contact-us')); ?>"><i class="fa fa-phone"></i> Contact Us</a></li>
            <li class="active">Reply</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="box box-warning">

            <!-- /.box-header -->
            <div class="box-body">
                <form role="form" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label>Email</label>
                        <div class="form-control"><?php echo e($contact_details->email); ?></div>
                    </div>
                    <div class="form-group">
                        <label>Message</label>
                        <textarea class="form-control" readonly=""><?php echo e($contact_details->message); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Reply Text</label>
                        <textarea class="form-control" placeholder="Enter ..." name="reply_text" id="reply_text"><?php echo e(!empty($contact_details->replies)?$contact_details->replies->reply_text:''); ?></textarea>
                    </div>
                    <?php if(empty($contact_details->replies)): ?>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Reply</button>
                    </div>
                    <?php endif; ?>

                </form>
            </div>
            <!-- /.box-body -->
        </div>
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_content'); ?>
<script src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/admin/reply-contact-us.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>