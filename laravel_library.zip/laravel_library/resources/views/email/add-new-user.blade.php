<div>
    Welcome to Enyota
    <br/>
    <br/>
    This is your Login details:
    <br/>
    <br/>
    User name : {{$email}}
    <br/>
    Password : {{$password}}
</div>