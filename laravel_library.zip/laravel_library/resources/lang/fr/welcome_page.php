<?php

return array(
    'home' => 'Homef',
    'about_us' => 'About Usf',
    'terms_and_condition' => 'Terms and Conditionsf',
    'privacy_policy' => 'Privacy Policyf',
    'contact' => 'Contactf',
);
