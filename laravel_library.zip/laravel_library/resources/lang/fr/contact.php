<?php

return array (
  'drop_your_message' => 'BAISSEZ VOTRE MESSAGE',
  'contact_us_short_description' => 'contactez l\'administrateur pour plus de questions.',
  'email' => 'Email',
  'message' => 'Message',
  'submit_message' => 'Soumettre un message',
);
