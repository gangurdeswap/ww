<?php

return array (
  'drop_your_message' => 'test swap',
  'contact_us_short_description' => 'contacto con el administrador para más quries.',
  'email' => 'Correo Electrónico',
  'message' => 'Mensaje',
  'submit_message' => 'Enviar mensaje',
);
