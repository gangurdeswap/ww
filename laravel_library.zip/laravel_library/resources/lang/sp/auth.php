<?php

return array (
  'failed' => 'gdgdf',
  'throttle' => 'gdfgdg',
  'new' => 'dfgdfgd',
  'testnewkey' => 'ggf454545',
  'fdfsdfdsfs' => 'ghfhfhfh',
);
