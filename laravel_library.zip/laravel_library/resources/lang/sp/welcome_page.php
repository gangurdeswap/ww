<?php

return array(
    'home' => 'Homes',
    'about_us' => 'About Uss',
    'terms_and_condition' => 'Terms and Conditionss',
    'privacy_policy' => 'Privacy Policys',
    'contact' => 'Contacts',
);
