<?php

return array (
  'failed' => 'sdd These credentials do not match our records.',
  'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
  'new' => 'fd',
  'testnewkey' => 'fsdfsfs1234',
  'fdfsdfdsfs' => 'hgfhfhf',
);
