<?php

return array (
  'drop_your_message' => 'Drop Your Message',
  'contact_us_short_description' => 'contact to admin for more quries.',
  'email' => 'Email',
  'message' => 'Message',
  'submit_message' => 'Submit Message',
);
