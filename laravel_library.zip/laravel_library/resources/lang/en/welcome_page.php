<?php

return array(
    'home' => 'Home',
    'about_us' => 'About Us',
    'terms_and_condition' => 'Terms and Conditions',
    'privacy_policy' => 'Privacy Policy',
    'contact' => 'Contact',
);
