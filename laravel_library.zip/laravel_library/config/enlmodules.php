<?php

return [
    'modules' => array(
        // Add Your Module Name Here
        "admin",
        "user"
    ),
    'super-admin-layout' => 'layouts.app',
    'admin-layout' => 'layouts.admin',
    'user-layout' => 'layouts.user',
    'user-activity-layout' => 'layouts.user-activity',
];
